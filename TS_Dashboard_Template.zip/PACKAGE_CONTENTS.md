# Deployment Package Contents

**Sea Cadets Training Dashboard V2.2.1-Cloud**

---

## Files Included

### 1. **setup_database.sql** (11 KB)
Complete database setup script for Supabase.

**Creates:**
- 5 tables (personnel, qualifications, junior_module_completions, user_profiles, upload_history)
- Row Level Security (RLS) policies
- Indexes for performance
- Automatic user profile creation trigger

**Usage:**
Copy entire file → Paste into Supabase SQL Editor → Run

---

### 2. **index-template.html** (542 KB)
Dashboard HTML file with placeholder credentials.

**Before deployment:**
- Replace `YOUR_SUPABASE_URL_HERE` with your Supabase project URL
- Replace `YOUR_SUPABASE_ANON_KEY_HERE` with your anon/public key
- Save as `index.html`

**Features:**
- Cadet Focus (individual tracking)
- Junior Focus (junior section)
- SCC CTP / RMC CTS Progress (training planners)
- Waterborne tracking
- Awards & certificates
- Training suggestions
- Upload history
- Multi-user support with admin controls

---

### 3. **README.md** (6.1 KB)
Complete step-by-step deployment guide.

**Covers:**
- Creating Supabase project
- Running database setup
- Configuring HTML with credentials
- Creating first admin user
- Uploading Westminster data
- Deploying to web (Netlify/Vercel/GitHub)
- Inviting other staff members

**Time estimate:** 45-60 minutes

---

### 4. **TROUBLESHOOTING.md** (7.7 KB)
Solutions to common issues.

**Sections:**
- Installation problems
- Authentication issues
- Data loading errors
- Display problems
- RLS policy violations
- Performance optimization
- Multi-user issues
- Database recovery

**Pro tip:** Check here FIRST before asking for help!

---

### 5. **CHECKLIST.md** (3.5 KB)
Track your deployment progress.

**Checkboxes for:**
- Pre-deployment prep
- Database setup
- Credential collection
- Dashboard configuration
- Admin user creation
- Data upload
- Web deployment
- Staff invitations
- Feature testing

---

### 6. **index.html** (542 KB)
**DO NOT DISTRIBUTE THIS FILE - Contains your live credentials!**

This is YOUR working dashboard with real Supabase credentials. 
Other units should use `index-template.html` instead.

---

## What Other Units Need

When sharing with other units, give them:

✅ `setup_database.sql`
✅ `index-template.html` (NOT index.html)
✅ `README.md`
✅ `TROUBLESHOOTING.md`
✅ `CHECKLIST.md`

❌ **DO NOT SHARE:** `index.html` (contains your credentials)

---

## Quick Start for Other Units

1. **Create Supabase project** (free tier works)
2. **Run `setup_database.sql`** in SQL Editor
3. **Edit `index-template.html`** with their credentials
4. **Create admin user** via SQL
5. **Upload Westminster CSVs**
6. **Deploy** to Netlify/Vercel (optional)

**Time:** ~1 hour total

---

## Security Notes

### Safe to Share:
- ✅ setup_database.sql (no credentials)
- ✅ index-template.html (placeholder credentials)
- ✅ Documentation files

### Never Share:
- ❌ Your Supabase database password
- ❌ Your Supabase service_role key
- ❌ Your index.html with real credentials
- ❌ Westminster CSV files (contains personal data)

### Public but Safe:
- ✅ Supabase URL (public anyway)
- ✅ Supabase anon key (designed to be public)

**Why?** 
- Anon key only works with RLS policies enabled
- RLS restricts what users can see/do
- Service role key bypasses RLS (keep secret!)

---

## Deployment Platforms

**Recommended:**
1. **Netlify** - Easiest (drag & drop)
2. **Vercel** - Fast & reliable
3. **GitHub Pages** - Free & simple

**All free tiers work fine for this dashboard.**

---

## Support & Updates

**Issues/Bugs:** jharbidge@mhseacadets.org  
**Feature Requests:** Same email  
**Improvements:** Please share back with the community!

---

## Version History

- **V2.2.1** (Current) - Junior attribution, admin-only JSON
- **V2.2.0** - Upload history tracking
- **V2.1.0** - Single-unit shared data
- **V2.0.0** - Cloud migration (Supabase)

---

## License

Created independently by volunteers, not an official MSSC product.

Provided "as is" with no warranty. Use at your own risk.

If you improve it, please share! 🎖️

---

**Package created:** January 2026  
**Dashboard version:** V2.2.1-Cloud  
**For:** UK Sea Cadet Units
