# Quick Start Checklist

Use this to track your deployment progress.

---

## Pre-Deployment

- [ ] Downloaded deployment package
- [ ] Created Supabase account at https://supabase.com
- [ ] Have Westminster CSV files ready (Personnel + Qualifications)

---

## Database Setup (15 minutes)

- [ ] Created new Supabase project
- [ ] Noted down database password (save somewhere safe)
- [ ] Ran `setup_database.sql` in SQL Editor
- [ ] Verified tables created (check Table Editor - should see 5 tables)

---

## Get Credentials (2 minutes)

- [ ] Copied Project URL from Project Settings → API
- [ ] Copied anon public key from Project Settings → API
- [ ] Saved both somewhere temporarily

---

## Configure Dashboard (5 minutes)

- [ ] Opened `index-template.html` in text editor
- [ ] Replaced `YOUR_SUPABASE_URL_HERE` with actual URL
- [ ] Replaced `YOUR_SUPABASE_ANON_KEY_HERE` with actual key
- [ ] Saved file as `index.html`

---

## Create Admin User (5 minutes)

- [ ] Opened `index.html` in browser (locally)
- [ ] Signed up with my email address
- [ ] Confirmed email (if required)
- [ ] Copied my User ID from Authentication → Users in Supabase
- [ ] Ran SQL to make myself admin:
  ```sql
  UPDATE user_profiles SET is_admin = true WHERE id = 'MY_USER_ID';
  ```
- [ ] Refreshed dashboard - can see "Data / Utilities" menu item

---

## Upload Data (10 minutes)

- [ ] Downloaded Westminster Personnel CSV
- [ ] Downloaded Westminster Qualifications CSV  
- [ ] Logged into dashboard as admin
- [ ] Went to Data / Utilities
- [ ] Uploaded Personnel CSV
- [ ] Uploaded Qualifications CSV
- [ ] Checked Cadet Focus view - can see cadets
- [ ] Checked CTP Progress view - can see module grid

---

## Deploy to Web (Optional - 10 minutes)

- [ ] Chose hosting platform (Netlify/Vercel/GitHub Pages)
- [ ] Uploaded `index.html` to hosting
- [ ] Tested public URL - can access dashboard
- [ ] Tested sign up with different email - works
- [ ] Tested read-only access for non-admin - works

---

## Invite Staff (5 minutes per person)

- [ ] Shared dashboard URL with staff
- [ ] Confirmed they can sign up
- [ ] Confirmed they can view data (read-only)
- [ ] Made additional admins if needed (SQL UPDATE)

---

## Test Core Features

- [ ] Can view all cadets in Cadet Focus
- [ ] Can track junior modules in Junior Focus
- [ ] Can see training progress in CTP/CTS views
- [ ] Can generate certificates in Awards view
- [ ] Upload history showing in Data/Utilities

---

## Optional Enhancements

- [ ] Uploaded unit crest logo
- [ ] Uploaded SCC logo
- [ ] Uploaded RMC logo  
- [ ] Tested certificate generation with logos
- [ ] Customized any hardcoded text (unit name, etc)

---

## Maintenance Schedule

Set reminders:

- [ ] **Weekly:** Check upload history - who's uploading what?
- [ ] **Monthly:** Upload fresh Westminster CSVs
- [ ] **Quarterly:** Review admin users - remove leavers
- [ ] **Yearly:** Archive old qualifications data (if database getting large)

---

## Emergency Contacts

**Supabase Support:** https://supabase.com/support  
**Dashboard Issues:** jharbidge@mhseacadets.org  
**Database Password:** [WRITE IT DOWN SOMEWHERE SAFE]

---

## Success Criteria

✅ **You're done when:**
- Admins can upload Westminster CSVs
- All staff can view cadet data
- Junior modules being tracked
- Certificates generating correctly
- Multiple users can access simultaneously

---

**Deployment Time:** ~45-60 minutes total  
**Ongoing Maintenance:** ~10 minutes/month

Good luck! 🎖️
