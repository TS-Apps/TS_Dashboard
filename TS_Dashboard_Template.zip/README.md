# Sea Cadets Training Dashboard - Deployment Guide

**Version:** V2.2.1-Cloud  
**For:** Other Sea Cadet units wanting to deploy their own dashboard

---

## What You'll Get

A complete training dashboard with:
- **Cadet Focus** - individual progress tracking
- **Junior Focus** - dedicated junior section management
- **SCC CTP / RMC CTS Progress** - training planner grids
- **Waterborne** - proficiency tracking
- **Awards** - certificates and recognition
- **Training Planner** - what to teach tonight

**Multi-user support:**
- Admins can upload Westminster CSVs
- All staff can view data and track juniors
- Secure cloud storage (Supabase)

---

## Prerequisites

You'll need:
1. **Supabase Account** (free tier works fine) - https://supabase.com
2. **Westminster CSV Access** - Personnel + Qualifications reports
3. **Web Hosting** (optional - Netlify/Vercel/GitHub Pages)

---

## Deployment Steps

### STEP 1: Create Supabase Project

1. Go to https://supabase.com and sign up
2. Click "New Project"
3. Fill in:
   - **Name:** `sea-cadets-dashboard` (or your unit name)
   - **Database Password:** (save this somewhere safe)
   - **Region:** Choose closest to UK
4. Wait 2-3 minutes for project to be created

### STEP 2: Run Database Setup Script

1. In your Supabase project, go to **SQL Editor** (left sidebar)
2. Click **New Query**
3. Open `setup_database.sql` from this package
4. Copy the entire contents and paste into the SQL editor
5. Click **Run** (bottom right)
6. You should see "Success. No rows returned" - this is correct!

### STEP 3: Get Your Supabase Credentials

1. Go to **Project Settings** (gear icon, bottom left)
2. Click **API** in the left menu
3. Copy these two values:
   - **Project URL** (looks like `https://xxxxx.supabase.co`)
   - **anon public** key (long string starting with `eyJ...`)

### STEP 4: Configure Dashboard HTML

1. Open `index.html` from this package in a text editor
2. Find this section near the top (around line 90):

```javascript
const SUPABASE_URL = 'YOUR_SUPABASE_URL_HERE';
const SUPABASE_ANON_KEY = 'YOUR_SUPABASE_ANON_KEY_HERE';
```

3. Replace with your actual values:

```javascript
const SUPABASE_URL = 'https://xxxxx.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGc...your-long-key-here';
```

4. Save the file

### STEP 5: Create Your First Admin User

**Option A: Test Locally First (Recommended)**

1. Open the edited `index.html` in your web browser
2. Click "Sign Up" and create an account with your email
3. Go back to Supabase → **Authentication** → **Users**
4. Find your email and copy your **User ID** (UUID format)
5. Go to **SQL Editor** and run:

```sql
UPDATE user_profiles 
SET is_admin = true 
WHERE id = 'paste-your-user-id-here';
```

6. Refresh your dashboard - you should now see admin features!

**Option B: Direct SQL**

If you already know your email address:

```sql
-- Find your user ID
SELECT id, email FROM auth.users WHERE email = 'your-email@example.com';

-- Make yourself admin (use the ID from above)
UPDATE user_profiles SET is_admin = true WHERE id = 'your-user-id';
```

### STEP 6: Upload Your Data

1. Log in to your dashboard as admin
2. Navigate to **Data / Utilities**
3. Download your Westminster reports:
   - **Personnel Report** (CSV)
   - **Qualifications Report** (CSV)
4. Upload both CSVs using the upload buttons
5. Click through the dashboard views to confirm data loaded

### STEP 7: Deploy to Web (Optional)

**If you want others to access it:**

**Option A: Netlify (Easiest)**
1. Go to https://app.netlify.com
2. Sign up with GitHub/Email
3. Drag and drop your `index.html` file
4. Done! You get a free URL like `https://your-unit.netlify.app`

**Option B: GitHub Pages**
1. Create GitHub account
2. Create new repository called `sea-cadets-dashboard`
3. Upload `index.html` (rename to `index.html` if needed)
4. Go to Settings → Pages → Enable
5. Your URL: `https://yourusername.github.io/sea-cadets-dashboard`

**Option C: Vercel**
1. Go to https://vercel.com
2. Import your GitHub repo or upload file
3. Deploy

### STEP 8: Invite Other Staff

1. Share your dashboard URL with staff
2. They click "Sign Up" and create accounts
3. They automatically get read-only access
4. To make someone admin:

```sql
-- In Supabase SQL Editor:
UPDATE user_profiles 
SET is_admin = true 
WHERE email = 'staff-email@example.com';
```

---

## File Structure

```
deployment-package/
├── setup_database.sql      # Complete database setup
├── index.html              # Dashboard (YOU MUST EDIT THIS)
├── README.md               # This file
└── TROUBLESHOOTING.md      # Common issues and fixes
```

---

## Security Notes

✅ **Data is secure:**
- Stored in your private Supabase database
- Only visible to authenticated users from your unit
- Row Level Security (RLS) enforced

✅ **Admin controls:**
- Only admins can upload Westminster CSVs
- Only admins can import/export junior data
- Everyone can track junior modules they manage

⚠️ **Important:**
- Your Supabase anon key is public (safe to commit)
- Your Supabase service role key is SECRET (never share)
- Don't share your database password

---

## Updating Westminster Data

As your admin:

1. Download fresh CSVs from Westminster
2. Go to **Data / Utilities**
3. Upload Personnel CSV (replaces old data)
4. Upload Qualifications CSV (replaces old data)
5. Junior modules are preserved (stored separately)

---

## Support

This dashboard was created independently by volunteers. For issues:

1. Check `TROUBLESHOOTING.md` in this package
2. Contact James Harbidge: jharbidge@mhseacadets.org

---

## License & Disclaimer

This app was built independently and is not an official MSSC product. It's provided "as is" with no warranty. Use at your own risk.

Parts of the solution may be AI-generated. Always review outputs for accuracy.

If you spot bugs or make improvements, please share so others can benefit!

---

## Version History

- **V2.2.1** - Junior module attribution, admin-only JSON import/export
- **V2.2.0** - Upload history tracking
- **V2.1.0** - Single-unit shared data model
- **V2.0.0** - Cloud migration (Supabase)
- **V1.0** - Local-only version

---

**Happy training! 🎖️**
