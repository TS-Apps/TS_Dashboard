-- ============================================================================
-- SEA CADETS TRAINING DASHBOARD - COMPLETE DATABASE SETUP
-- ============================================================================
-- Version: V2.2.1-Cloud
-- Description: Creates all tables, policies, and functions needed for the dashboard
-- 
-- INSTRUCTIONS:
-- 1. Create new Supabase project at https://supabase.com
-- 2. Go to SQL Editor in your project
-- 3. Copy/paste this entire script
-- 4. Click "Run" to execute
-- 5. Create your first admin user (see STEP 5 below)
-- ============================================================================

-- ============================================================================
-- STEP 1: CREATE TABLES
-- ============================================================================

-- User Profiles (tracks admin permissions)
CREATE TABLE IF NOT EXISTS user_profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    email TEXT NOT NULL,
    is_admin BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Personnel Data (cadet information from Westminster)
CREATE TABLE IF NOT EXISTS personnel (
    p_number TEXT PRIMARY KEY,
    rank TEXT NOT NULL,
    name TEXT NOT NULL,
    unit TEXT,
    dob DATE,
    tos DATE,
    rank_date DATE,
    cvqo TEXT,
    user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Qualifications Data (module/badge completions from Westminster)
CREATE TABLE IF NOT EXISTS qualifications (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    p_number TEXT NOT NULL,
    module TEXT NOT NULL,
    date DATE,
    result TEXT,
    syllabus TEXT,
    user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(p_number, module, date)
);

-- Junior Module Completions (locally tracked junior progress)
CREATE TABLE IF NOT EXISTS junior_module_completions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    p_number TEXT NOT NULL,
    section TEXT NOT NULL CHECK (section IN ('red', 'blue', 'green', 'yellow', 'stem')),
    module_code TEXT NOT NULL,
    module_name TEXT,
    date_completed DATE NOT NULL,
    is_core BOOLEAN DEFAULT FALSE,
    added_by_email TEXT,
    added_at TIMESTAMPTZ DEFAULT NOW(),
    user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(p_number, section, module_code, date_completed)
);

-- Upload History (tracks who uploaded what and when)
CREATE TABLE IF NOT EXISTS upload_history (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
    user_email TEXT NOT NULL,
    upload_type TEXT NOT NULL CHECK (upload_type IN ('personnel', 'qualifications', 'junior_import', 'junior_export')),
    uploaded_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================================
-- STEP 2: CREATE INDEXES (for performance)
-- ============================================================================

CREATE INDEX IF NOT EXISTS idx_personnel_p_number ON personnel(p_number);
CREATE INDEX IF NOT EXISTS idx_personnel_rank ON personnel(rank);
CREATE INDEX IF NOT EXISTS idx_qualifications_p_number ON qualifications(p_number);
CREATE INDEX IF NOT EXISTS idx_qualifications_module ON qualifications(module);
CREATE INDEX IF NOT EXISTS idx_junior_p_number ON junior_module_completions(p_number);
CREATE INDEX IF NOT EXISTS idx_junior_section ON junior_module_completions(section);
CREATE INDEX IF NOT EXISTS idx_upload_history_user ON upload_history(user_id);
CREATE INDEX IF NOT EXISTS idx_upload_history_type ON upload_history(upload_type);

-- ============================================================================
-- STEP 3: ENABLE ROW LEVEL SECURITY (RLS)
-- ============================================================================

ALTER TABLE user_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE personnel ENABLE ROW LEVEL SECURITY;
ALTER TABLE qualifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE junior_module_completions ENABLE ROW LEVEL SECURITY;
ALTER TABLE upload_history ENABLE ROW LEVEL SECURITY;

-- ============================================================================
-- STEP 4: CREATE RLS POLICIES (single-unit shared data model)
-- ============================================================================

-- User Profiles: Users can only see their own profile
DROP POLICY IF EXISTS "Users can view own profile" ON user_profiles;
CREATE POLICY "Users can view own profile"
    ON user_profiles FOR SELECT
    USING (auth.uid() = id);

DROP POLICY IF EXISTS "Users can update own profile" ON user_profiles;
CREATE POLICY "Users can update own profile"
    ON user_profiles FOR UPDATE
    USING (auth.uid() = id);

-- Personnel: Everyone can read, only admins can write
DROP POLICY IF EXISTS "Everyone can view personnel" ON personnel;
CREATE POLICY "Everyone can view personnel"
    ON personnel FOR SELECT
    USING (true);

DROP POLICY IF EXISTS "Admins can insert personnel" ON personnel;
CREATE POLICY "Admins can insert personnel"
    ON personnel FOR INSERT
    WITH CHECK (
        EXISTS (
            SELECT 1 FROM user_profiles
            WHERE id = auth.uid() AND is_admin = true
        )
    );

DROP POLICY IF EXISTS "Admins can update personnel" ON personnel;
CREATE POLICY "Admins can update personnel"
    ON personnel FOR UPDATE
    USING (
        EXISTS (
            SELECT 1 FROM user_profiles
            WHERE id = auth.uid() AND is_admin = true
        )
    );

DROP POLICY IF EXISTS "Admins can delete personnel" ON personnel;
CREATE POLICY "Admins can delete personnel"
    ON personnel FOR DELETE
    USING (
        EXISTS (
            SELECT 1 FROM user_profiles
            WHERE id = auth.uid() AND is_admin = true
        )
    );

-- Qualifications: Everyone can read, only admins can write
DROP POLICY IF EXISTS "Everyone can view qualifications" ON qualifications;
CREATE POLICY "Everyone can view qualifications"
    ON qualifications FOR SELECT
    USING (true);

DROP POLICY IF EXISTS "Admins can insert qualifications" ON qualifications;
CREATE POLICY "Admins can insert qualifications"
    ON qualifications FOR INSERT
    WITH CHECK (
        EXISTS (
            SELECT 1 FROM user_profiles
            WHERE id = auth.uid() AND is_admin = true
        )
    );

DROP POLICY IF EXISTS "Admins can update qualifications" ON qualifications;
CREATE POLICY "Admins can update qualifications"
    ON qualifications FOR UPDATE
    USING (
        EXISTS (
            SELECT 1 FROM user_profiles
            WHERE id = auth.uid() AND is_admin = true
        )
    );

DROP POLICY IF EXISTS "Admins can delete qualifications" ON qualifications;
CREATE POLICY "Admins can delete qualifications"
    ON qualifications FOR DELETE
    USING (
        EXISTS (
            SELECT 1 FROM user_profiles
            WHERE id = auth.uid() AND is_admin = true
        )
    );

-- Junior Module Completions: Everyone can read and write (JTOs track their juniors)
DROP POLICY IF EXISTS "Everyone can view junior modules" ON junior_module_completions;
CREATE POLICY "Everyone can view junior modules"
    ON junior_module_completions FOR SELECT
    USING (true);

DROP POLICY IF EXISTS "Everyone can insert junior modules" ON junior_module_completions;
CREATE POLICY "Everyone can insert junior modules"
    ON junior_module_completions FOR INSERT
    WITH CHECK (true);

DROP POLICY IF EXISTS "Everyone can update junior modules" ON junior_module_completions;
CREATE POLICY "Everyone can update junior modules"
    ON junior_module_completions FOR UPDATE
    USING (true);

DROP POLICY IF EXISTS "Everyone can delete junior modules" ON junior_module_completions;
CREATE POLICY "Everyone can delete junior modules"
    ON junior_module_completions FOR DELETE
    USING (true);

-- Upload History: Everyone can view, admins can insert
DROP POLICY IF EXISTS "Everyone can view upload history" ON upload_history;
CREATE POLICY "Everyone can view upload history"
    ON upload_history FOR SELECT
    USING (true);

DROP POLICY IF EXISTS "Admins can insert upload history" ON upload_history;
CREATE POLICY "Admins can insert upload history"
    ON upload_history FOR INSERT
    WITH CHECK (
        EXISTS (
            SELECT 1 FROM user_profiles
            WHERE id = auth.uid() AND is_admin = true
        )
    );

-- ============================================================================
-- STEP 5: CREATE HELPER FUNCTION (auto-create user profile on signup)
-- ============================================================================

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
    INSERT INTO public.user_profiles (id, email, is_admin)
    VALUES (
        NEW.id,
        NEW.email,
        false  -- New users are NOT admin by default
    );
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger to auto-create profile
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
    AFTER INSERT ON auth.users
    FOR EACH ROW
    EXECUTE FUNCTION public.handle_new_user();

-- ============================================================================
-- STEP 6: GRANT PERMISSIONS
-- ============================================================================

-- Grant access to authenticated users
GRANT USAGE ON SCHEMA public TO authenticated;
GRANT ALL ON ALL TABLES IN SCHEMA public TO authenticated;
GRANT ALL ON ALL SEQUENCES IN SCHEMA public TO authenticated;

-- ============================================================================
-- SETUP COMPLETE!
-- ============================================================================
-- 
-- NEXT STEPS:
-- 
-- 1. Create your first admin user:
--    a. Sign up at your dashboard (creates account with is_admin=false)
--    b. Find your user ID in Authentication > Users
--    c. Run this SQL (replace YOUR_USER_ID):
--
--       UPDATE user_profiles 
--       SET is_admin = true 
--       WHERE id = 'YOUR_USER_ID';
--
-- 2. Configure your dashboard HTML:
--    a. Replace SUPABASE_URL with your project URL
--    b. Replace SUPABASE_ANON_KEY with your anon/public key
--    c. Upload to your hosting (Netlify/Vercel/etc)
--
-- 3. Upload your Westminster CSV files:
--    a. Log in as admin
--    b. Go to Data/Utilities
--    c. Upload Personnel CSV and Qualifications CSV
--
-- 4. Invite other staff:
--    a. They sign up at your dashboard URL
--    b. They automatically get read-only access
--    c. Make them admin if needed (UPDATE user_profiles...)
--
-- ============================================================================
