# Troubleshooting Guide

Common issues and how to fix them.

---

## Installation Issues

### "Success. No rows returned" after running SQL

✅ **This is correct!** The SQL script creates tables and policies, which don't return data.

To verify it worked:
1. Go to **Table Editor** in Supabase
2. You should see: `personnel`, `qualifications`, `junior_module_completions`, `user_profiles`, `upload_history`

---

### Can't see tables in Table Editor

**Fix:**
1. Make sure you ran the complete SQL script
2. Check for error messages in SQL Editor
3. Try running the script again (it's safe - uses `IF NOT EXISTS`)

---

### "relation does not exist" errors

**Cause:** Tables weren't created properly

**Fix:**
1. Go to **SQL Editor** → **New Query**
2. Run: `SELECT tablename FROM pg_tables WHERE schemaname='public';`
3. If you don't see the 5 tables, re-run `setup_database.sql`

---

## Authentication Issues

### Can't sign up / sign in

**Check:**
1. Is your Supabase URL correct in `index.html`?
2. Is your anon key correct in `index.html`?
3. In Supabase → **Authentication** → **Providers**, is Email enabled?

**Fix Email Provider:**
1. Go to Supabase → **Authentication** → **Providers**
2. Click **Email**
3. Enable "Enable Email provider"
4. Save

---

### Signed up but not redirected to dashboard

**Cause:** Email confirmation required

**Fix:**
1. Check your email for confirmation link
2. OR disable email confirmation:
   - Supabase → **Authentication** → **Providers** → **Email**
   - Disable "Confirm email"
   - Save

---

### Created account but don't see admin features

**Cause:** You're not set as admin

**Fix:**
1. Supabase → **Authentication** → **Users**
2. Find your email, copy your User ID
3. Supabase → **SQL Editor** → Run:
```sql
UPDATE user_profiles SET is_admin = true WHERE id = 'YOUR_USER_ID';
```

---

## Data Loading Issues

### Upload button does nothing

**Check browser console:**
1. Press F12
2. Look for errors in Console tab
3. Common issues:
   - CSV file too large (>10MB)
   - Invalid CSV format
   - Not logged in as admin

---

### "RLS policy violation" when uploading

**Cause:** You're not an admin

**Fix:**
```sql
UPDATE user_profiles SET is_admin = true WHERE email = 'your-email@example.com';
```

---

### Data uploads but dashboard shows nothing

**Check:**
1. Hard refresh browser (Ctrl+Shift+R or Cmd+Shift+R)
2. Check Supabase → **Table Editor** → Do tables have data?
3. Check browser console for errors

---

### Junior modules not saving

**Check:**
1. Are you logged in? (Check top-right)
2. Is p_number field filled correctly?
3. Browser console errors?

**Common fix:**
```sql
-- Grant permissions (run in SQL Editor)
GRANT ALL ON junior_module_completions TO authenticated;
```

---

## Display Issues

### Dashboard looks broken / no styling

**Cause:** CSS/JavaScript not loading

**Check:**
1. View page source - is all code there?
2. Browser console errors?
3. Are you using a modern browser? (Chrome/Firefox/Edge/Safari)

---

### Images missing (rank badges, etc)

**Cause:** Media folder not included

**Fix:** This is expected - badge images are optional. Core functionality works without them.

To add images:
1. Create `media/` folder next to `index.html`
2. Add badge image files (`.webp` format)
3. Naming convention in code around line 1500

---

### "Loading..." never finishes

**Check browser console:**
1. F12 → Console tab
2. Look for CORS errors or network failures
3. Verify Supabase URL is accessible (paste in browser - should see JSON)

**Fix:**
```javascript
// In index.html, check line ~90:
const SUPABASE_URL = 'https://xxxxx.supabase.co';  // Must end with .co NOT .com
```

---

## RLS Policy Issues

### "new row violates row-level security policy"

**Cause:** RLS policies are blocking insert/update

**Quick fix (testing only):**
```sql
-- Temporarily disable RLS on a table:
ALTER TABLE personnel DISABLE ROW LEVEL SECURITY;

-- Re-enable after testing:
ALTER TABLE personnel ENABLE ROW LEVEL SECURITY;
```

**Proper fix:**
Re-run the relevant section of `setup_database.sql` (Step 4)

---

### Can see data but can't modify

**Check:**
```sql
-- Are you admin?
SELECT id, email, is_admin FROM user_profiles WHERE email = 'your-email@example.com';

-- Should show is_admin = true
```

---

## Performance Issues

### Dashboard slow to load

**Optimize:**
1. Reduce number of cadets (split by section?)
2. Add indexes (already in setup script)
3. Use browser with good JavaScript performance (Chrome recommended)

**Check:**
```sql
-- How many records?
SELECT COUNT(*) FROM personnel;
SELECT COUNT(*) FROM qualifications;
SELECT COUNT(*) FROM junior_module_completions;

-- If >10,000 qualifications, consider archiving old data
```

---

### CSV upload times out

**Fix:**
1. Split large CSV files
2. Remove unnecessary columns before upload
3. Increase timeout (advanced - not recommended)

---

## Multi-User Issues

### Other users can't see data

**Check:**
1. Are they logged in?
2. RLS policies correct? (Run Step 4 of `setup_database.sql`)
3. Browser console errors on their machine?

---

### Staff member needs admin access

```sql
-- Option 1: Use their email
UPDATE user_profiles SET is_admin = true WHERE email = 'staff@example.com';

-- Option 2: Use their user ID
UPDATE user_profiles SET is_admin = true WHERE id = 'their-user-id';
```

---

## Supabase Specific

### Hit free tier limits

**Limits:**
- 500MB database
- 2GB bandwidth/month
- 50,000 monthly active users

**Solutions:**
1. Archive old qualifications data
2. Upgrade to Pro tier (£20/month)
3. Self-host PostgreSQL (advanced)

---

### Can't access Supabase dashboard

**Check:**
1. Correct project URL?
2. Not logged out?
3. Try incognito/private window

---

### Lost database password

**Don't worry!** You can:
1. Reset password via Supabase dashboard
2. Database password only needed for direct connections
3. Dashboard uses anon key (which you have)

---

## Database Issues

### Need to reset everything

```sql
-- DANGER: Deletes all data!
DROP TABLE IF EXISTS upload_history CASCADE;
DROP TABLE IF EXISTS junior_module_completions CASCADE;
DROP TABLE IF EXISTS qualifications CASCADE;
DROP TABLE IF EXISTS personnel CASCADE;
DROP TABLE IF EXISTS user_profiles CASCADE;

-- Then re-run setup_database.sql
```

---

### Duplicate data after upload

**Cause:** Uploading same CSV twice

**Fix:**
```sql
-- Clear duplicates:
DELETE FROM qualifications WHERE id NOT IN (
    SELECT MIN(id) FROM qualifications 
    GROUP BY p_number, module, date
);
```

---

### Junior data not showing

**Check:**
1. Browser console logs
2. Supabase → **Table Editor** → `junior_module_completions` has data?
3. RLS policies correct?

**Test query:**
```sql
SELECT * FROM junior_module_completions LIMIT 10;
-- If this works but dashboard doesn't, it's a frontend issue
```

---

## Browser Issues

### Works in Chrome, broken in Safari/Firefox

**Known issues:**
- Some ES6 features may need polyfills
- Local storage differences
- CORS handling varies

**Fix:**
Use Chrome/Edge for best compatibility (or help contribute Safari fixes!)

---

## Still Stuck?

If none of these fixes work:

1. **Check browser console** (F12 → Console) - screenshot any errors
2. **Check Supabase logs** (Logs & Analytics in sidebar)
3. **Email James Harbidge:** jharbidge@mhseacadets.org

**Include:**
- Browser version
- Error messages
- What you were trying to do
- Screenshots if possible

---

## Pro Tips

✅ **Test locally first** before deploying to web
✅ **Use Chrome DevTools** to debug JavaScript errors  
✅ **Check Supabase logs** for database errors
✅ **Make yourself admin FIRST** before uploading data
✅ **Hard refresh** (Ctrl+Shift+R) after code changes

---

**Most common issue:** Forgetting to set is_admin = true! 🎯
